﻿namespace ProcessFlow.Models
{
    public class SubProcess : ProcessBase
    {
        public string? ProcessId { get; set; }
        public string? Documentation { get; set; }
    }
}
