﻿namespace ProcessFlow.Models
{
    public class ProcessDatabaseSettings
    {
        public string? ConnectionString { get; set; }
        public string? DatabaseName { get; set; }
        public string? AreaCollectionName { get; set; }
    }
}
