﻿namespace ProcessFlow.Models
{
    public class Process : ProcessBase
    {
        public List<SubProcessModel>? SubProcessModels { get; set; }
    }
}
