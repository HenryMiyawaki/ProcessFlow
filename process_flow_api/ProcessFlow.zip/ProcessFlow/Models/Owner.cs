﻿namespace ProcessFlow.Models
{
    public class Owner
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
    }
}
